<?php
// Heading
$_['heading_title'] = 'World Map';

$_['text_order']    = 'Orders';
$_['text_sale']     = 'Sales';